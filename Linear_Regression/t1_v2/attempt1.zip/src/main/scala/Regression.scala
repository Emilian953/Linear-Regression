import Matrix.*

import scala.annotation.tailrec

object Regression {

  def computeCost(X: Matrix, y: Matrix, W: Matrix): Double = {
    val m = X.height.getOrElse(0) // Numărul de exemple de antrenament
    val predictions = X * W
    val sqrErrors = (predictions - y).map(x => x * x)
    sqrErrors.data.getOrElse(List(List(0.0))).flatten.sum / (2 * m)
  }

  def gradientDescent(X: Matrix, y: Matrix, W: Matrix, alpha: Double, num_iters: Int): Matrix = {
    val m = y.height.getOrElse(0).toDouble

    @tailrec
    def loop(iter: Int, currentW: Matrix): Matrix = {
      if (iter <= 0) currentW
      else {
        val predictions = X * currentW
        val errors = predictions - y
        val gradient = (X.transpose * errors) / m
        val adjustment = gradient.map(_ * alpha)
        val updatedW = currentW - adjustment
        loop(iter - 1, updatedW)
      }
    }

    loop(num_iters, W)
  }

  def regression(dataset_file: String,
                attribute_columns: List[String],
                value_column: String,
                test_percentage: Double,
                alpha: Double,
                gradient_descent_steps: Int): (Matrix, Double) = {

    val dataset = Dataset.apply(dataset_file)
    val (trainingSet, validationSet) = dataset.split(test_percentage)

    // Crearea matricelor X și y pentru antrenament
    val X_train = Matrix.apply(trainingSet.selectColumns(attribute_columns)).++(1.0)
    val y_train = Matrix.apply(trainingSet.selectColumn(value_column))

    // Inițializarea coeficienților W
    val W_init = new Matrix(Some(List.fill(attribute_columns.size + 1)(List(0.0))))

    // Aplicarea Gradient Descent
    val W_optimized = gradientDescent(X_train, y_train, W_init, alpha, gradient_descent_steps)

    // Prepararea datelor de validare
    val X_validation = Matrix.apply(validationSet.selectColumns(attribute_columns)).++(1.0)
    val y_validation = Matrix.apply(validationSet.selectColumn(value_column))

    // Calculul costului pe setul de validare
    val validation_cost = computeCost(X_validation, y_validation, W_optimized)

    // Returnarea coeficienților optimizați și a costului pe setul de validare
    (W_optimized, validation_cost)
  }

  def main(args: Array[String]): Unit = {
    // Exemplu de utilizare
    print(regression("datasets/houseds.csv", List("GrLivArea", "YearBuilt"), "SalePrice", 0.1, 1e-7, 10000))
  }
}