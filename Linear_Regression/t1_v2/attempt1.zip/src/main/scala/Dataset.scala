import scala.annotation.tailrec

class Dataset(m: List[List[String]]) {
  val data: List[List[String]] = m
  override def toString: String = {
    data.map(row => row.mkString(", ")).mkString("\n")
  }

  def selectColumn(col: String): Dataset = {
    val idx = data.head.indexOf(col)
    val column = data.map(row => List(row(idx)))
    new Dataset(column)
  }

  def selectColumns(cols: List[String]): Dataset = {
    val indexes = cols.map(col => data.head.indexOf(col))
    val columns = data.map(row => indexes.map(idx => row(idx)))
    new Dataset(columns)
  }


  def split(percentage: Double): (Dataset, Dataset) = {
    val sortedData = data.tail.sortBy(_.head)

    // Calculăm numărul de intrări pentru setul de test
    val testSize = Math.ceil(size * percentage).toInt
    val step = Math.ceil(1.0 / percentage).toInt

    @tailrec
    def helper(sortedData: List[List[String]], index: Int = 1, train: List[List[String]] = List(data.head),
               test: List[List[String]] = List(data.head)): (List[List[String]], List[List[String]]) = {
      sortedData match {
        case head :: tail =>
          if (index % step == 0)
            helper(tail, index + 1, train, test :+ head) // Adaugă în setul de test
          else
            helper(tail, index + 1, train :+ head, test) // Adaugă în setul de antrenament
        case Nil => (train, test)
      }
    }

    // Aplicăm funcția ajutătoare pentru a obține cele două seturi
    val (trainSet, testSet) = helper(sortedData)

    // Creăm și returnăm noile dataset-uri
    (new Dataset(trainSet), new Dataset(testSet))

  }


  def size: Int = data.length - 1
  def getRows: List[List[String]] = data.tail
  def getHeader: List[String] = data.head
}

object Dataset {
  def apply(csv_filename: String): Dataset = {
    val source = scala.io.Source.fromFile(csv_filename)
    val lines = source.getLines().toList
    val data = lines.map(_.split(",").map(_.trim).toList)
    new Dataset(data)
  }

  def apply(ds: List[List[String]]): Dataset = new Dataset(ds)
}
